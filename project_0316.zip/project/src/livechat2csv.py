import os
import json
import csv
import re
import time
from datetime import datetime

import yt_dlp

input_folder = "../outputs/01_live_scan"
output_folder = "../outputs/02_livechat2csv"

if not os.path.exists(output_folder):
    os.makedirs(output_folder)


def extract_video_id(url):
    """
    YouTube の URL から動画 ID を抽出する関数。
    
    対応形式:
    - https://www.youtube.com/watch?v=VIDEO_ID
    - https://youtu.be/VIDEO_ID
    """
    pattern = r"(?:v=|be/)([a-zA-Z0-9_-]{11})"
    match = re.search(pattern, url)
    return match.group(1) if match else None


def download_live_chat(video_id, output_folder):

    # フォルダが存在しない場合は作成
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # yt-dlp オプション
    ydl_opts = {
        'format': 'best',
        'outtmpl': f'{output_folder}/%(id)s.mp4',
        'writesubtitles': True,
        'skip_download': True,
        'writeinfojson': False,   # 動画のメタ情報JSONは不要
        'write_live_chat': True,  # ライブチャットのJSONを取得
    }


    video_url = f'https://www.youtube.com/watch?v={video_id}'
    
    # ライブチャットJSONのパス
    live_chat_json_path = os.path.join(output_folder, f"{video_id}.live_chat.json")

    if os.path.isfile(live_chat_json_path) == False:
        # ダウンロード処理
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            res = ydl.extract_info(video_url, download=False)
            ydl.download([video_url])

        # ライブチャットJSONのパス
        live_chat_json_path = os.path.join(output_folder, f"{res['id']}.live_chat.json")

    
    # JSONファイルの存在確認
    if not os.path.exists(live_chat_json_path):
        print("ライブチャットJSONが見つかりません。")
        return

    # JSONの読み込みとチャットデータの抽出
    with open(live_chat_json_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    chat_messages = []
    for line in lines:
        if line.strip():
            try:
                l_json = json.loads(line)
                actions = l_json.get("replayChatItemAction", {}).get("actions", [])
                for action in actions:
                    if "addChatItemAction" in action:
                        chat_item = action["addChatItemAction"].get("item", {})
                        if "liveChatTextMessageRenderer" in chat_item:
                            renderer = chat_item["liveChatTextMessageRenderer"]
                            timestamp_usec = renderer.get("timestampUsec", None)
                            if not timestamp_usec:
                                continue  # timestampUsecがない場合はスキップ
                            message_runs = renderer.get("message", {}).get("runs", [])
                            message = ''.join(run.get("text", "") for run in message_runs)
                            timestamp = datetime.fromtimestamp(float(timestamp_usec) / 1_000_000).strftime('%H:%M:%S')
                            chat_messages.append([timestamp, message])
            except json.JSONDecodeError:
                continue

    # CSVに書き出し
    output_csv_path = os.path.join(output_folder, f"{video_id}.csv")
    with open(output_csv_path, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['timestamp', 'message'])
        writer.writerows(chat_messages)

    print(f"ライブチャットを {output_csv_path} に保存しました。")

# Iterate through all files in the input_folder
all_data = []
for filename in os.listdir(input_folder):
    if filename.endswith('.json'):  # Check if the file is a JSON file
        file_path = os.path.join(input_folder, filename)
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
            all_data.extend(data)

for data in all_data:
    url = data['url']
    video_id = extract_video_id(url)
    print(f"・URL: {url} -> Video ID: {video_id}")

    download_live_chat(video_id, output_folder)