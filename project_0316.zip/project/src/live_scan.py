import os
import json
import datetime
import googleapiclient.discovery

API_KEY = "AIzaSyBbbxt_emwqIotRXo0SUGDF-K517z6PfB0" 

CHANNEL_IDS =  [
    # {"channel_id": "UCt9H_RpQzhxzlyBxFqrdHqA", "channel_name": "FUWAMOCO Ch. hololive-EN"},
    {"channel_id": "UCMwGHR0BTZuLsmjY_NT5Pwg", "channel_name": "Ninomae Ina'nis Ch. hololive-EN"},
    # {"channel_id": "UC9p_lqQ0FEDz327Vgf5JwqA", "channel_name": "Koseki Bijou Ch. hololive-EN"},
    # {"channel_id": "UCgmPnx-EEeOrZSg5Tiw7ZRQ", "channel_name": "Hakos Baelz Ch. hololive-EN"},
    # {"channel_id": "UC3n5uGu18FoCy23ggWWp8tA", "channel_name": "Nanashi Mumei Ch. hololive-EN"},
    # {"channel_id": "UCoSrY_IQQVpmIRZ9Xf-y93g", "channel_name": "Gawr Gura Ch. hololive-EN"}
]

# 過去7日間の動画を取得する期間を設定
num_days = 7
now = datetime.datetime.utcnow()
days_ago = now - datetime.timedelta(days=num_days)
published_after = days_ago.isoformat("T") + "Z" # ISO 8601形式で日時を文字列化

output_folder = "../outputs/01_live_scan"
output_json_file = f"{days_ago.strftime('%Y-%m-%d')}_{now.strftime('%Y-%m-%d')}.json"

output_json_path = os.path.join(output_folder, output_json_file)

print("output_json_path :", output_json_path)

if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# YouTube API クライアントを作成
youtube = googleapiclient.discovery.build("youtube", "v3", developerKey=API_KEY)

# 動画を検索
def get_recent_live_streams(channel_id, channel_name):
    request = youtube.search().list(
        part="snippet",
        channelId=channel_id,
        publishedAfter=published_after,
        maxResults=50,
        type="video",
        eventType="completed"
    )
    response = request.execute()

    # 動画データのリストを作成
    video_data = [
        {
            "url": f"https://www.youtube.com/watch?v={item['id']['videoId']}", 
            "title": item['snippet']['title'], 
            "channel_name": channel_name
        }
        for item in response.get("items", [])
    ]
    return video_data

# 全チャンネルの動画を取得
all_video_data = []
for channel in CHANNEL_IDS:
    print(channel["channel_name"])
    video_data = get_recent_live_streams(channel["channel_id"], channel["channel_name"])
    all_video_data.extend(video_data)

    # 取得したURLを出力
    for video in all_video_data:
        print(f"・{video['title']}: {video['url']}")
    
    print()

# 結果をJSONファイルに出力
with open(output_json_path, "w", encoding="utf-8") as f:
    json.dump(all_video_data, f, ensure_ascii=False, indent=4)