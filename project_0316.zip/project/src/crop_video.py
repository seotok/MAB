################ 自動切り抜き
import os
import pandas as pd
import matplotlib.pyplot as plt

from scipy.signal import find_peaks
from yt_dlp import YoutubeDL

input_folder = "../outputs/02_livechat2csv"
output_folder = "../outputs/03_crop_video"

if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# 動画のダウンロード範囲を作成
def convert_to_time_range(time_series):
    """タイムスタンプのSeriesをHH:MM:SSの範囲リストに変換"""
    ranges = []
    for ts in time_series:
        start_time = (ts - pd.Timedelta(seconds=30)).strftime("%H:%M:%S")  # 30秒前
        end_time = (ts + pd.Timedelta(seconds=30)).strftime("%H:%M:%S")  # 30秒後
        ranges.append((start_time, end_time))
    return ranges

# ダウンロード処理
def time_to_seconds(time_str):
    """HH:MM:SS形式の時間を秒に変換"""
    h, m, s = map(int, time_str.split(':'))
    return h * 3600 + m * 60 + s

def ytdlp_bytime(movie_url: str, time_ranges: list):
    video_files = []  # ダウンロードした動画のファイルパスを保存
    for idx, (start, end) in enumerate(time_ranges, start=1):
        video_path = os.path.join('base_videos', f'video_{idx}_{start}-{end}.mp4')

        def set_download_ranges(info_dict, self):
            start_seconds = time_to_seconds(start)
            end_seconds = time_to_seconds(end)
            return [{'start_time': start_seconds, 'end_time': end_seconds}]
        
        # yt-dlp の設定
        ydl_opts = {
            'outtmpl': video_path,
            'download_ranges': set_download_ranges
        }

        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([movie_url])

        video_files.append(video_path)

    return video_files


# 指定フォルダ内のすべてのCSVファイルを取得
csv_files = [f for f in os.listdir(input_folder) if f.endswith('.csv')]

for csv_file in csv_files:
    csv_path = os.path.join(input_folder, csv_file)
    print(f"Processing {csv_path}...")

    video_id = os.path.splitext(csv_file)[0]
    
    # CSVファイルを読み込む
    df = pd.read_csv(csv_path)

    # タイムスタンプを datetime 型に変換
    df["timestamp"] = pd.to_datetime(df["timestamp"], format="%H:%M:%S")

    # 1分ごとのコメント数を集計
    comment_counts = df.set_index("timestamp").resample("1min").count()

    # 局所的なピーク（盛り上がった時間）を検出
    peaks, _ = find_peaks(comment_counts["message"], height=comment_counts["message"].mean())

    # 盛り上がった時間帯を取得
    highlight_times = comment_counts.index[peaks]

    # ダウンロード時間範囲を作成
    time_ranges = convert_to_time_range(highlight_times)

    # プロット
    fig, ax = plt.subplots(figsize=(15, 5))
    ax.plot(comment_counts.index, comment_counts["message"], label="Comment Count", color="blue", lw=2)

    # 盛り上がった時間帯（ピーク）を赤でハイライト
    ax.plot(comment_counts.index[peaks], comment_counts["message"].iloc[peaks], 'ro', label="Peak")

    # グラフの表示を調整
    plt.xticks(rotation=45)
    plt.tight_layout()

    # 画像として保存
    output_image_path = os.path.join(output_folder, f"{video_id}.png")
    plt.savefig(output_image_path)

    # プロットを閉じる
    plt.close()

    print(f"Graph saved as {output_image_path}")

    # # 動画のURL（手動で設定）
    # movie_url = "youtubeのURL"

    # # 盛り上がった時間帯を出力
    # print("盛り上がった時間帯:")
    # for start, end in time_ranges:
    #     print(f"{start} - {end}")

    # # 盛り上がった時間帯の動画をダウンロード
    # downloaded_videos = ytdlp_bytime(movie_url, time_ranges)
