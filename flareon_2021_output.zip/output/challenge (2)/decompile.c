/* Function: FUN_00401000 */

int FUN_00401000(int param_1)

{
  int local_8;
  
  for (local_8 = 0; *(char *)(param_1 + local_8) != '\0'; local_8 = local_8 + 1) {
  }
  return local_8;
}



/* Function: FUN_00401030 */

int FUN_00401030(int param_1,int param_2)

{
  int local_8;
  
  for (local_8 = 0; *(undefined *)(param_1 + local_8) = *(undefined *)(param_2 + local_8),
      *(char *)(param_2 + local_8) != '\0'; local_8 = local_8 + 1) {
  }
  return local_8;
}



/* Function: FUN_00401070 */

char * FUN_00401070(uint param_1,char *param_2)

{
  if (9 < param_1) {
    param_2 = (char *)FUN_00401070(param_1 / 10,param_2);
  }
  *param_2 = (char)((ulonglong)param_1 % 10) + '0';
  param_2[1] = '\0';
  return param_2 + 1;
}



/* Function: FUN_004010c0 */

void FUN_004010c0(void *param_1)

{
  DWORD DVar1;
  LPDWORD pDVar2;
  undefined *puVar3;
  LPVOID pvVar4;
  undefined local_10 [12];
  
  puVar3 = local_10;
  DVar1 = GetLastError();
  FUN_00401070(DVar1,puVar3);
  pvVar4 = (LPVOID)0x0;
  pDVar2 = (LPDWORD)0x0;
  DVar1 = FUN_00401000(param_1);
  WriteConsoleA(DAT_00403844,param_1,DVar1,pDVar2,pvVar4);
  WriteConsoleA(DAT_00403844,s__failed__error_code_0040382c,0x14,(LPDWORD)0x0,(LPVOID)0x0);
  pvVar4 = (LPVOID)0x0;
  pDVar2 = (LPDWORD)0x0;
  DVar1 = FUN_00401000(local_10);
  WriteConsoleA(DAT_00403844,local_10,DVar1,pDVar2,pvVar4);
  WriteConsoleA(DAT_00403844,s__Make_sure_the_Files_directory_i_004037d8,0x50,(LPDWORD)0x0,
                (LPVOID)0x0);
                    /* WARNING: Subroutine does not return */
  ExitProcess(1);
}



/* Function: FUN_00401160 */

void FUN_00401160(int param_1)

{
  DWORD nNumberOfCharsToWrite;
  LPDWORD lpNumberOfCharsWritten;
  LPVOID lpReserved;
  undefined local_14 [12];
  DWORD local_8;
  
  FUN_00401070(param_1,local_14);
  WriteConsoleA(DAT_00403844,s_Number_of_files_decoded__004037bc,0x19,(LPDWORD)0x0,(LPVOID)0x0);
  lpReserved = (LPVOID)0x0;
  lpNumberOfCharsWritten = (LPDWORD)0x0;
  nNumberOfCharsToWrite = FUN_00401000(local_14);
  WriteConsoleA(DAT_00403844,local_14,nNumberOfCharsToWrite,lpNumberOfCharsWritten,lpReserved);
  if (param_1 == 0) {
    local_8 = 0x50;
  }
  else {
    local_8 = 1;
  }
  WriteConsoleA(DAT_00403844,s__Make_sure_the_Files_directory_i_00403768,local_8,(LPDWORD)0x0,
                (LPVOID)0x0);
  return;
}



/* Function: FUN_004011f0 */

void FUN_004011f0(int param_1,int param_2)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  
  uVar3 = 0;
  while (bVar2 = (byte)uVar3, (char)bVar2 < '\b') {
    bVar1 = *(byte *)(uVar3 + param_1) ^ *(byte *)(uVar3 + param_2);
    *(byte *)(uVar3 + param_1) = (bVar1 << (bVar2 & 7) | bVar1 >> 8 - (bVar2 & 7)) - bVar2;
    uVar3 = (uint)(byte)(bVar2 + 1);
  }
  return;
}



/* Function: FUN_00401220 */

void FUN_00401220(LPCSTR param_1,LPCSTR param_2,undefined4 param_3)

{
  BOOL BVar1;
  undefined local_1c [8];
  DWORD local_14;
  HANDLE local_10;
  HANDLE local_c;
  DWORD local_8;
  
  local_10 = CreateFileA(param_1,0x80000000,1,(LPSECURITY_ATTRIBUTES)0x0,3,0x80,(HANDLE)0x0);
  if (local_10 == (HANDLE)0xffffffff) {
    FUN_004010c0(param_1);
  }
  local_c = CreateFileA(param_2,0x40000000,0,(LPSECURITY_ATTRIBUTES)0x0,2,0x80,(HANDLE)0x0);
  if (local_c == (HANDLE)0xffffffff) {
    FUN_004010c0(param_2);
  }
  while( true ) {
    BVar1 = ReadFile(local_10,local_1c,8,&local_8,(LPOVERLAPPED)0x0);
    if (BVar1 == 0) {
      FUN_004010c0(param_1);
    }
    if (local_8 == 0) break;
    FUN_004011f0(local_1c,param_3);
    BVar1 = WriteFile(local_c,local_1c,local_8,&local_14,(LPOVERLAPPED)0x0);
    if (BVar1 == 0) {
      FUN_004010c0(param_2);
    }
  }
  CloseHandle(local_c);
  CloseHandle(local_10);
  local_8 = FUN_00401000(param_1);
  param_2[local_8 - 10] = '\n';
  WriteConsoleA(DAT_00403844,param_1,local_8,(LPDWORD)0x0,(LPVOID)0x0);
  WriteConsoleA(DAT_00403844,&DAT_00403760,4,(LPDWORD)0x0,(LPVOID)0x0);
  WriteConsoleA(DAT_00403844,param_2,local_8 - 9,(LPDWORD)0x0,(LPVOID)0x0);
  return;
}



/* Function: FUN_00401370 */

bool FUN_00401370(undefined4 param_1)

{
  BOOL BVar1;
  DWORD DVar2;
  _WIN32_FIND_DATAA local_194;
  undefined local_54 [64];
  int local_14;
  HANDLE local_c;
  int local_8;
  
  local_8 = 0;
  BVar1 = SetCurrentDirectoryA(s_Files_00403758);
  if (BVar1 == 0) {
    FUN_004010c0(s_SetCurrentDirectory__Files___00403738);
  }
  local_c = FindFirstFileA(s___encrypted_0040372c,&local_194);
  if (local_c == (HANDLE)0xffffffff) {
    FUN_004010c0(s_FindFirstFile_0040371c);
  }
  while( true ) {
    do {
      local_14 = FUN_00401030(local_54,local_194.cFileName);
      local_194.cAlternateFileName[local_14 + 6] = '\0';
      FUN_00401220(local_194.cFileName,local_54,param_1);
      local_8 = local_8 + 1;
      BVar1 = FindNextFileA(local_c,&local_194);
    } while (BVar1 != 0);
    DVar2 = GetLastError();
    if (DVar2 == 0x12) break;
    FUN_004010c0(s_FindNextFile_0040370c);
  }
  FUN_00401160(local_8);
  return local_8 != 0;
}



/* Function: entry */

void entry(void)

{
  UINT uExitCode;
  undefined4 local_14;
  undefined4 local_10;
  DWORD local_c;
  HANDLE local_8;
  
  local_14 = 0;
  local_10 = 0;
  local_8 = GetStdHandle(0xfffffff6);
  DAT_00403844 = GetStdHandle(0xfffffff5);
  SetConsoleTextAttribute(DAT_00403844,0xce);
  WriteConsoleA(DAT_00403844,s____________Attention_____________00403000,0x70a,(LPDWORD)0x0,
                (LPVOID)0x0);
  ReadConsoleA(local_8,&local_14,8,&local_c,(PCONSOLE_READCONSOLE_CONTROL)0x0);
  uExitCode = FUN_00401370(&local_14);
                    /* WARNING: Subroutine does not return */
  ExitProcess(uExitCode);
}



