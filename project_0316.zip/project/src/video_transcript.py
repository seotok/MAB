###########　文字お越し
from clipsai import Transcriber

# 文字起こし処理
def transcribe_videos(video_files):
    transcriber = Transcriber()
    
    for video_file in video_files:
        transcription = transcriber.transcribe(audio_file_path=video_file)

        # 文字起こし結果をテキストファイルに保存
        text_file = video_file.replace(".mp4", ".txt")
        with open(text_file, "w", encoding="utf-8") as f:
            f.write(transcription.text)

        print(f"文字起こし完了: {text_file}")

# 文字起こし実行
transcribe_videos(downloaded_videos)