/* Function: FUN_0051452c */

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Instruction at (ram,0x00514656) overlaps instruction at (ram,0x00514654)
    */
/* WARNING: This function may have set the stack pointer */
/* WARNING: Removing unreachable block (ram,0x00514642) */

void __fastcall FUN_0051452c(int param_1,undefined4 param_2)

{
  char *pcVar1;
  char cVar2;
  bool bVar3;
  uint uVar4;
  code *pcVar5;
  byte *pbVar6;
  byte bVar7;
  byte bVar8;
  undefined uVar9;
  uint uVar10;
  undefined4 uVar11;
  undefined3 uVar12;
  uint uVar13;
  undefined4 extraout_ECX;
  int extraout_ECX_00;
  undefined2 uVar14;
  int iVar15;
  int extraout_EDX;
  uint unaff_EBX;
  int *piVar16;
  undefined *puVar17;
  undefined6 *unaff_EDI;
  int in_GS_OFFSET;
  char in_AF;
  byte bVar18;
  undefined8 uVar19;
  
  pcVar1 = (char *)(unaff_EBX + 0x3204273f);
  cVar2 = *pcVar1;
  *pcVar1 = *pcVar1 + '\x01';
  piVar16 = (int *)(unaff_EBX & 0xffffff00);
  bVar7 = in_AF * -6 + 0x33;
  bVar8 = 0x9f < bVar7 | in_AF * (bVar7 < 6);
  if (SCARRY1(cVar2,'\x01') == false) {
    *(char *)(param_1 + 0x475507e) = (*(char *)(param_1 + 0x475507e) - (char)param_1) - bVar8;
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bVar18 = 1;
  iVar15 = CONCAT22((short)((uint)param_2 >> 0x10),
                    CONCAT11((byte)((uint)param_2 >> 8) | *(byte *)((int)unaff_EDI + -0x611ea8ab),
                             (char)param_2)) + 1;
  if (-1 < iVar15) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bVar8 = bVar7 + bVar8 * -0x60 | 0x18;
  uVar13 = param_1 - 1;
  if (uVar13 == 0 || bVar8 == 0) {
    *piVar16 = *piVar16 + -0x7ebf47d2;
    DAT_816948f0 = DAT_816948f0 + -0x58;
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar17 = (undefined *)*unaff_EDI;
  if ((char)bVar8 < '\0') {
    pcVar5 = (code *)swi(0x14);
    uVar19 = (*pcVar5)(0x6e01e240,piVar16);
    iVar15 = (int)((ulonglong)uVar19 >> 0x20);
    uVar10 = (uint)uVar19;
    pbVar6 = (byte *)(iVar15 * 2);
    bVar8 = (byte)((uint)extraout_ECX >> 8);
    uVar13 = (uint)CARRY1(bVar8,*pbVar6);
    uVar4 = uVar10 + 0x132e6893;
    uVar11 = in(0x37);
    out(0xc1,(char)uVar11);
    bVar3 = (uVar10 >= 0xecd1976d && uVar4 >= uVar13) && uVar4 != uVar13;
    if (bVar3) {
      unaff_EDI = (undefined6 *)0x868f7c0a;
    }
    else {
      piVar16 = (int *)((uint)CONCAT21((short)(unaff_EBX >> 0x10),
                                       (byte)(unaff_EBX >> 8) |
                                       *(byte *)((int)unaff_EDI +
                                                CONCAT31(CONCAT21((short)((uint)extraout_ECX >> 0x10
                                                                         ),bVar8 + *pbVar6),0xe7) *
                                                4 + -0x7a)) << 8);
    }
    pcVar1 = (char *)(iVar15 + 0x5d35bb12);
    *pcVar1 = (*pcVar1 + '\x04') - (bVar3 && (uVar10 < 0xecd1976d || uVar4 < uVar13));
    pcVar5 = (code *)swi(0x8e);
    (*pcVar5)();
    in((short)extraout_EDX);
    if (piVar16 != (int *)0xffffff8d) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar13 = extraout_ECX_00 - 1;
    if (uVar13 != 0 && piVar16 == (int *)0xffffff8d) {
      xabort(0xd);
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar9 = in((short)extraout_EDX);
    iVar15 = extraout_EDX + 1;
    out((short)iVar15,uVar9);
    if (SCARRY4(extraout_EDX,1) != iVar15 < 0) {
      bRamffffff8d = bRamffffff8d ^ (byte)((uint)iVar15 >> 8);
      uVar11 = in((short)iVar15);
      *(undefined4 *)unaff_EDI = uVar11;
      *(undefined *)(in_GS_OFFSET + extraout_ECX_00 + -0x73) = 0x8d;
      puVar17 = puVar17 + -1;
      uVar13 = uVar13 | (uint)puVar17;
    }
  }
  else {
    swi(4);
  }
  DAT_ff91375c = in(0);
  bVar8 = (byte)uVar13 | 0x5b;
  bVar18 = 9 < (bVar8 & 0xf) | bVar18;
  bVar8 = bVar8 + bVar18 * -6;
  uVar13 = CONCAT31((int3)(uVar13 >> 8),bVar8 + (0x9f < bVar8 | bVar18 * (bVar8 < 6)) * -0x60) ^
           (uint)&stack0x00000000;
  uVar14 = (undefined2)iVar15;
  out(*puVar17,uVar14);
  uVar12 = (undefined3)(uVar13 + *(int *)(uVar13 + 0xd84edc68) >> 8);
  cRamd6c08086 = in(uVar14);
  cVar2 = cRamd6c08086 - *(char *)(((uint)puVar17 & CONCAT31(uVar12,cRamd6c08086)) * 3 + 0x383101c8)
  ;
  *(char *)(CONCAT31(uVar12,cVar2) + -0x24fb134e) = cVar2;
  out(uVar14,cVar2);
  pcVar5 = (code *)swi(3);
  (*pcVar5)();
  return;
}



/* Function: entry */

/* WARNING: Instruction at (ram,0x0059264f) overlaps instruction at (ram,0x0059264e)
    */
/* WARNING: Control flow encountered bad instruction data */

void entry(void)

{
  byte bVar1;
  undefined uVar2;
  char cVar3;
  byte bVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  HMODULE hModule;
  FARPROC pFVar8;
  byte *pbVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  FARPROC *ppFVar13;
  uint uVar14;
  uint *puVar15;
  UINT unaff_EDI;
  undefined4 *puVar16;
  byte *lpProcName;
  byte *pbVar17;
  byte *pbVar18;
  bool bVar19;
  bool bVar20;
  bool bVar21;
  
  puVar15 = &DAT_00514000;
  puVar16 = (undefined4 *)&DAT_00401000;
  uVar14 = 0xffffffff;
LAB_00592522:
  uVar11 = *puVar15;
  bVar19 = puVar15 < (uint *)0xfffffffc;
  puVar15 = puVar15 + 1;
  bVar20 = CARRY4(uVar11,uVar11) || CARRY4(uVar11 * 2,(uint)bVar19);
  uVar11 = uVar11 * 2 + (uint)bVar19;
LAB_00592529:
  if (!bVar20) {
    iVar6 = 1;
    do {
      bVar19 = CARRY4(uVar11,uVar11);
      uVar11 = uVar11 * 2;
      if (uVar11 == 0) {
        uVar11 = *puVar15;
        bVar20 = puVar15 < (uint *)0xfffffffc;
        puVar15 = puVar15 + 1;
        bVar19 = CARRY4(uVar11,uVar11) || CARRY4(uVar11 * 2,(uint)bVar20);
        uVar11 = uVar11 * 2 + (uint)bVar20;
      }
      uVar7 = iVar6 * 2 + (uint)bVar19;
      uVar12 = uVar11 * 2;
      if (CARRY4(uVar11,uVar11)) {
        if (uVar12 != 0) goto LAB_0059255c;
        uVar11 = *puVar15;
        bVar19 = puVar15 < (uint *)0xfffffffc;
        puVar15 = puVar15 + 1;
        uVar12 = uVar11 * 2 + (uint)bVar19;
        if (CARRY4(uVar11,uVar11) || CARRY4(uVar11 * 2,(uint)bVar19)) goto LAB_0059255c;
      }
      bVar19 = CARRY4(uVar12,uVar12);
      uVar11 = uVar12 * 2;
      if (uVar11 == 0) {
        uVar11 = *puVar15;
        bVar20 = puVar15 < (uint *)0xfffffffc;
        puVar15 = puVar15 + 1;
        bVar19 = CARRY4(uVar11,uVar11) || CARRY4(uVar11 * 2,(uint)bVar20);
        uVar11 = uVar11 * 2 + (uint)bVar20;
      }
      iVar6 = (uVar7 - 1) * 2 + (uint)bVar19;
    } while( true );
  }
  uVar2 = *(undefined *)puVar15;
  puVar15 = (uint *)((int)puVar15 + 1);
  *(undefined *)puVar16 = uVar2;
  puVar16 = (undefined4 *)((int)puVar16 + 1);
  goto LAB_0059251e;
LAB_0059255c:
  if (uVar7 < 3) {
    bVar19 = CARRY4(uVar12,uVar12);
    uVar12 = uVar12 * 2;
    if (uVar12 == 0) {
      uVar11 = *puVar15;
      bVar20 = puVar15 < (uint *)0xfffffffc;
      puVar15 = puVar15 + 1;
      bVar19 = CARRY4(uVar11,uVar11) || CARRY4(uVar11 * 2,(uint)bVar20);
      uVar12 = uVar11 * 2 + (uint)bVar20;
    }
  }
  else {
    uVar2 = *(undefined *)puVar15;
    puVar15 = (uint *)((int)puVar15 + 1);
    uVar14 = CONCAT31((int3)uVar7 + -3,uVar2) ^ 0xffffffff;
    if (uVar14 == 0) {
      puVar16 = (undefined4 *)&DAT_00401000;
      iVar6 = 0x62e4;
      do {
        cVar3 = *(char *)puVar16;
        puVar16 = (undefined4 *)((int)puVar16 + 1);
        while (((byte)(cVar3 + 0x18U) < 2 && (*(char *)puVar16 == '\''))) {
          uVar5 = *puVar16;
          cVar3 = *(char *)(puVar16 + 1);
          *puVar16 = &DAT_00401000 +
                     (CONCAT31(CONCAT21((ushort)uVar5 >> 8,(char)((uint)uVar5 >> 0x10)),
                               (char)((uint)uVar5 >> 0x18)) - (int)puVar16);
          puVar16 = (undefined4 *)((int)puVar16 + 5);
          iVar6 = iVar6 + -1;
          if (iVar6 == 0) {
            lpProcName = pu__L_c_4___K_C_0_L_D_S_R_I_T_C_C_B_0058ea3d.opaque_data + 0x5c2;
            do {
              if (*(int *)lpProcName == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              ppFVar13 = (FARPROC *)(&DAT_00401000 + *(int *)(lpProcName + 4));
              pbVar18 = lpProcName + 8;
              hModule = LoadLibraryA((LPCSTR)((int)&DWORD_00595510 + *(int *)lpProcName));
              while( true ) {
                bVar4 = *pbVar18;
                lpProcName = pbVar18 + 1;
                if (bVar4 == 0) break;
                if ((char)bVar4 < '\0') {
                  lpProcName = (byte *)(uint)*(ushort *)lpProcName;
                  pbVar18 = pbVar18 + 3;
                }
                else {
                  pbVar9 = lpProcName;
                  pbVar17 = lpProcName;
                  do {
                    pbVar18 = pbVar17;
                    if (pbVar9 == (byte *)0x0) break;
                    pbVar9 = pbVar9 + -1;
                    pbVar18 = pbVar17 + 1;
                    bVar1 = *pbVar17;
                    pbVar17 = pbVar18;
                  } while ((byte)(bVar4 - 1) != bVar1);
                }
                pFVar8 = GetProcAddress(hModule,(LPCSTR)lpProcName);
                if (pFVar8 == (FARPROC)0x0) {
                    /* WARNING: Subroutine does not return */
                  ExitProcess(unaff_EDI);
                }
                *ppFVar13 = pFVar8;
                ppFVar13 = ppFVar13 + 1;
              }
            } while( true );
          }
        }
      } while( true );
    }
    bVar19 = (uVar14 & 1) != 0;
    uVar14 = (int)uVar14 >> 1;
  }
  bVar20 = CARRY4(uVar12,uVar12);
  uVar11 = uVar12 * 2;
  if (uVar11 == 0) {
    uVar11 = *puVar15;
    bVar21 = puVar15 < (uint *)0xfffffffc;
    puVar15 = puVar15 + 1;
    bVar20 = CARRY4(uVar11,uVar11) || CARRY4(uVar11 * 2,(uint)bVar21);
    uVar11 = uVar11 * 2 + (uint)bVar21;
  }
  iVar6 = (uint)bVar19 * 2 + (uint)bVar20;
  if (iVar6 == 0) {
    iVar6 = 1;
    do {
      do {
        bVar19 = CARRY4(uVar11,uVar11);
        uVar12 = uVar11 * 2;
        if (uVar12 == 0) {
          uVar11 = *puVar15;
          bVar20 = puVar15 < (uint *)0xfffffffc;
          puVar15 = puVar15 + 1;
          bVar19 = CARRY4(uVar11,uVar11) || CARRY4(uVar11 * 2,(uint)bVar20);
          uVar12 = uVar11 * 2 + (uint)bVar20;
        }
        iVar6 = iVar6 * 2 + (uint)bVar19;
        uVar11 = uVar12 * 2;
      } while (!CARRY4(uVar12,uVar12));
      if (uVar11 != 0) break;
      uVar12 = *puVar15;
      bVar19 = puVar15 < (uint *)0xfffffffc;
      puVar15 = puVar15 + 1;
      uVar11 = uVar12 * 2 + (uint)bVar19;
    } while (!CARRY4(uVar12,uVar12) && !CARRY4(uVar12 * 2,(uint)bVar19));
    iVar6 = iVar6 + 2;
  }
  uVar12 = iVar6 + 1 + (uint)(uVar14 < 0xfffffb00);
  puVar10 = (undefined4 *)((int)puVar16 + uVar14);
  if (uVar14 < 0xfffffffd) {
    do {
      uVar5 = *puVar10;
      puVar10 = puVar10 + 1;
      *puVar16 = uVar5;
      puVar16 = puVar16 + 1;
      bVar19 = 3 < uVar12;
      uVar12 = uVar12 - 4;
    } while (bVar19 && uVar12 != 0);
    puVar16 = (undefined4 *)((int)puVar16 + uVar12);
  }
  else {
    do {
      uVar2 = *(undefined *)puVar10;
      puVar10 = (undefined4 *)((int)puVar10 + 1);
      *(undefined *)puVar16 = uVar2;
      puVar16 = (undefined4 *)((int)puVar16 + 1);
      uVar12 = uVar12 - 1;
    } while (uVar12 != 0);
  }
LAB_0059251e:
  bVar20 = CARRY4(uVar11,uVar11);
  uVar11 = uVar11 * 2;
  if (uVar11 == 0) goto LAB_00592522;
  goto LAB_00592529;
}



